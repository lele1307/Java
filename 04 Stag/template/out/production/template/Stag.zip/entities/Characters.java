package entities;

/**
 * @author dukehan
 */
public class Characters extends Entities {
    public Characters(String name,String description){
        super(name,description);
    }
}
