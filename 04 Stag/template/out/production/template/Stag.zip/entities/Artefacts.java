package entities;
/**
 * @author dukehan
 */
public class Artefacts extends Entities {
    public Artefacts(String name, String description){
        super(name,description);
    }
}
