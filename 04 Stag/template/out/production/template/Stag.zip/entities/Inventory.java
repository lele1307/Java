package entities;

/**
 * @author dukehan
 */
public class Inventory extends Entities {
    public Inventory(String name,String description){
        super(name,description);
    }
}
