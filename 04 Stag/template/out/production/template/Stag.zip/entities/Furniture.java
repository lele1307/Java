package entities;

/**
 * @author dukehan
 */
public class Furniture extends Entities {
    public Furniture(String name,String description){
        super(name,description);
    }
}
