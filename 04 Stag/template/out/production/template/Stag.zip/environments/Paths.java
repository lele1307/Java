package environments;

/**
 * @author dukehan
 */
public class Paths {
    private String start;

    private String target;

    public Paths(String start,String target){
        this.start = start;
        this.target = target;
    }

    public String getStart() {
        return start;
    }

    public String getTarget() {
        return target;
    }

}
